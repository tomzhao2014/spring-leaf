This is the PHP version of template. Not using any framework or database, etc...
Just for demonstration.
Using the same data and template files as the nodejs version.

View it like this:
http://localhost/path_to_ace/mustache/php/

